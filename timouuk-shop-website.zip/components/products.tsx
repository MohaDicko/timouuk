import { Card, CardContent } from "@/components/ui/card"
import { Sparkles, ShoppingBag, Watch, Flower } from "lucide-react"

const products = [
  {
    title: "Habaya",
    description: "Collection exclusive de Habaya élégantes et modernes",
    icon: Sparkles,
    image: "/elegant-black-abaya-fashion.jpg",
  },
  {
    title: "Accessoires & Chaussures",
    description: "Sacs à main raffinés et chaussures tendance",
    icon: ShoppingBag,
    image: "/luxury-handbags-and-shoes-display.jpg",
  },
  {
    title: "Montres",
    description: "Montres élégantes pour compléter votre style",
    icon: Watch,
    image: "/elegant-luxury-watches-display.jpg",
  },
  {
    title: "Parfums en Vrac",
    description: "Fragrances authentiques et envoûtantes",
    icon: Flower,
    image: "/luxury-perfume-bottles-display.jpg",
  },
]

export function Products() {
  return (
    <section id="collection" className="py-24 md:py-32">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="font-serif text-4xl md:text-6xl font-light mb-4 text-balance">Notre Collection</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto text-pretty">
            {"Découvrez nos produits soigneusement sélectionnés pour sublimer votre élégance"}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {products.map((product, index) => {
            const Icon = product.icon
            return (
              <Card
                key={index}
                className="group overflow-hidden border-0 shadow-lg hover:shadow-xl transition-all duration-300"
              >
                <CardContent className="p-0">
                  <div className="relative h-80 overflow-hidden">
                    <img
                      src={product.image || "/placeholder.svg"}
                      alt={product.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-primary/80 to-transparent" />
                    <div className="absolute bottom-0 left-0 right-0 p-8 text-primary-foreground">
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-12 h-12 rounded-full bg-secondary/20 backdrop-blur-sm flex items-center justify-center">
                          <Icon className="w-6 h-6 text-secondary" />
                        </div>
                        <h3 className="font-serif text-3xl font-light">{product.title}</h3>
                      </div>
                      <p className="text-primary-foreground/90 text-pretty">{product.description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>
    </section>
  )
}

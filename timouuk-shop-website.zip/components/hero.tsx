import { Button } from "@/components/ui/button"
import { Instagram, Facebook } from "lucide-react"

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-primary">
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/50 to-primary" />
        <img
          src="/elegant-abaya-fashion-boutique-display.jpg"
          alt="Timouuk Collection"
          className="w-full h-full object-cover opacity-40"
        />
      </div>

      <div className="relative z-10 container mx-auto px-4 text-center text-primary-foreground">
        <h1 className="font-serif text-6xl md:text-8xl lg:text-9xl font-light mb-6 tracking-tight text-balance">
          Timouuk
        </h1>
        <p className="text-xl md:text-2xl mb-12 max-w-2xl mx-auto font-light tracking-wide text-pretty">
          {"Élégance & Raffinement"}
        </p>
        <div className="flex items-center justify-center gap-4 flex-wrap">
          <Button size="lg" variant="secondary" className="font-medium" asChild>
            <a href="#collection">Découvrir la collection</a>
          </Button>
          <div className="flex items-center gap-3">
            <a
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              className="w-10 h-10 rounded-full bg-primary-foreground/10 hover:bg-primary-foreground/20 flex items-center justify-center transition-colors"
              aria-label="Instagram"
            >
              <Instagram className="w-5 h-5" />
            </a>
            <a
              href="https://facebook.com"
              target="_blank"
              rel="noopener noreferrer"
              className="w-10 h-10 rounded-full bg-primary-foreground/10 hover:bg-primary-foreground/20 flex items-center justify-center transition-colors"
              aria-label="Facebook"
            >
              <Facebook className="w-5 h-5" />
            </a>
          </div>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 text-primary-foreground/60 animate-bounce">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <polyline points="6 9 12 15 18 9" />
        </svg>
      </div>
    </section>
  )
}
